
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white font-sans">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center">
        <img
          src="/images/gym1.jpg"
          alt="Home Gym"
          className="absolute w-full h-full object-cover opacity-40"
        />
        <div className="relative z-10 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Sculpt by Seb</h1>
          <p className="text-xl md:text-2xl mb-6">Train Hard. Sculpt Strong. Built by Seb.</p>
          <Button className="text-lg px-6 py-3">Book a Session</Button>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 px-6 md:px-16 bg-gray-900">
        <h2 className="text-4xl font-bold mb-8 text-center">My Story</h2>
        <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8 items-center">
          <img src="/images/gym2.jpg" alt="Seb transformation" className="rounded-2xl shadow-lg" />
          <p className="text-lg">
            I started lifting in high school and transformed my body naturally — gaining 30 lbs of muscle and adding 120 lbs to my bench press. Now, I help others do the same with private training, small group sessions, and tailored nutrition coaching.
          </p>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-6 md:px-16">
        <h2 className="text-4xl font-bold mb-12 text-center">Training Options</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { title: "1-on-1 Training", text: "Personalized strength and conditioning in a private, high-end home gym." },
            { title: "Group Sessions", text: "Train with up to 4 people — motivating, affordable, and fun." },
            { title: "Nutrition Coaching", text: "Custom macros and meal planning to fuel your results." },
          ].map(({ title, text }) => (
            <Card key={title} className="bg-gray-800 text-white">
              <CardContent className="p-6">
                <h3 className="text-2xl font-semibold mb-2">{title}</h3>
                <p className="text-base mb-4">{text}</p>
                <Button>Book Now</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 px-6 md:px-16 bg-gray-900">
        <h2 className="text-4xl font-bold mb-8 text-center">The Gym</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {["gym1.jpg", "gym2.jpg", "gym3.jpg", "gym4.jpg"].map((img, i) => (
            <img key={i} src={`/images/${img}`} alt={`Gym ${i + 1}`} className="rounded-xl shadow-md" />
          ))}
        </div>
      </section>

      {/* Contact/Booking Section */}
      <section className="py-20 px-6 md:px-16 text-center">
        <h2 className="text-4xl font-bold mb-6">Book a Session</h2>
        <form
          action="https://formspree.io/f/mpwrykky"
          method="POST"
          className="max-w-xl mx-auto grid gap-6 text-left"
        >
          <div>
            <label className="block mb-1">Name</label>
            <input type="text" name="name" required className="w-full p-3 rounded-lg bg-gray-800 text-white" />
          </div>
          <div>
            <label className="block mb-1">Email</label>
            <input type="email" name="email" required className="w-full p-3 rounded-lg bg-gray-800 text-white" />
          </div>
          <div>
            <label className="block mb-1">Service</label>
            <select name="service" className="w-full p-3 rounded-lg bg-gray-800 text-white">
              <option>1-on-1 Training</option>
              <option>Group Session</option>
              <option>Nutrition Coaching</option>
            </select>
          </div>
          <div>
            <label className="block mb-1">Preferred Date/Time</label>
            <input type="text" name="datetime" className="w-full p-3 rounded-lg bg-gray-800 text-white" />
          </div>
          <div>
            <label className="block mb-1">Message</label>
            <textarea name="message" rows="4" className="w-full p-3 rounded-lg bg-gray-800 text-white"></textarea>
          </div>
          <Button type="submit" className="w-full py-3 text-lg">Send Request</Button>
        </form>
        <p className="text-lg mt-8">Based in Madison, NJ</p>
        <p className="text-lg">Email: sculptbyseb@gmail.com | Phone: (555) 123-4567</p>
      </section>
    </div>
  );
}
