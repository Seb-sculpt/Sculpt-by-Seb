# Sculpt by Seb

**Sculpt by Seb** is a bold, high-performance personal training website built using React and Tailwind CSS. It showcases private training, group sessions, nutrition coaching, and a high-end home gym located in Madison, NJ.

## 💪 Features

- Hero landing with call to action
- About section with Seb's transformation story
- Services with booking buttons
- Image gallery of the gym
- Contact + booking form (powered by Formspree)

## 🚀 How to Run

1. Clone the repo:
   ```
   git clone https://github.com/YOUR_USERNAME/sculpt-by-seb.git
   ```
2. Navigate to the folder:
   ```
   cd sculpt-by-seb
   ```
3. Install dependencies:
   ```
   npm install
   ```
4. Start the dev server:
   ```
   npm run dev
   ```

## 📬 Booking Form

Form submissions go to: `sculptbyseb@gmail.com` via [Formspree.io](https://formspree.io)

## 📍 Location

Madison, New Jersey

---

Built by Sebastian Friedmann
